import { cacheGet, cacheSet } from "../config/redis.js";
import { queryPool, getStatement } from "../utils/queryOptimizer.js";

export class OptimizedQueryService {
  constructor() {
    this.queryStats = new Map();
  }

  async getAccountWithCache(userId, accountId, ttl = 300) {
    const cacheKey = `account:${userId}:${accountId}`;

    // Try cache first
    const cached = await cacheGet(cacheKey);
    if (cached) {
      this.recordHit(cacheKey);
      return JSON.parse(cached);
    }

    // Query database
    const query = `
      SELECT * FROM stored_accounts 
      WHERE user_id = ? AND account_id = ?
      LIMIT 1
    `;

    const result = await queryPool.executeSingle(query, [userId, accountId]);

    if (result) {
      await cacheSet(cacheKey, result, ttl);
      this.recordMiss(cacheKey);
    }

    return result;
  }

  async getMultipleAccounts(userId, limit = 50, offset = 0) {
    const cacheKey = `accounts:${userId}:${limit}:${offset}`;

    const cached = await cacheGet(cacheKey);
    if (cached) {
      this.recordHit(cacheKey);
      return JSON.parse(cached);
    }

    const query = `
      SELECT id, account_id, public_key, balance, created_at
      FROM stored_accounts
      WHERE user_id = ?
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `;

    const results = await queryPool.execute(query, [userId, limit, offset]);

    await cacheSet(cacheKey, results, 600);
    this.recordMiss(cacheKey);

    return results;
  }

  async getTransactionStats(userId, daysBack = 30) {
    const cacheKey = `stats:${userId}:${daysBack}`;

    const cached = await cacheGet(cacheKey);
    if (cached) {
      this.recordHit(cacheKey);
      return JSON.parse(cached);
    }

    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    // Multi-part query optimized
    const queries = [
      {
        name: "summary",
        sql: `
          SELECT 
            COUNT(*) as total,
            SUM(amount) as volume,
            AVG(amount) as avg_amount
          FROM transaction_logs
          WHERE user_id = ? AND created_at >= ?
        `,
        params: [userId, startDate.toISOString()],
      },
      {
        name: "byType",
        sql: `
          SELECT tx_type, COUNT(*) as count, SUM(amount) as volume
          FROM transaction_logs
          WHERE user_id = ? AND created_at >= ?
          GROUP BY tx_type
        `,
        params: [userId, startDate.toISOString()],
      },
    ];

    // Execute in parallel
    const [summary, byType] = await Promise.all(
      queries.map((q) => queryPool.execute(q.sql, q.params))
    );

    const stats = {
      summary: summary[0],
      byType,
    };

    await cacheSet(cacheKey, stats, 1800);
    this.recordMiss(cacheKey);

    return stats;
  }

  recordHit(key) {
    const stats = this.queryStats.get(key) || { hits: 0, misses: 0 };
    stats.hits++;
    this.queryStats.set(key, stats);
  }

  recordMiss(key) {
    const stats = this.queryStats.get(key) || { hits: 0, misses: 0 };
    stats.misses++;
    this.queryStats.set(key, stats);
  }

  getStats() {
    const stats = Array.from(this.queryStats.entries()).map(([key, value]) => ({
      key,
      hitRate: ((value.hits / (value.hits + value.misses)) * 100).toFixed(2) + "%",
      ...value,
    }));

    return stats.sort((a, b) => b.hits - a.hits);
  }
}

export const queryService = new OptimizedQueryService();