import Database from "better-sqlite3";
import { v4 as uuidv4 } from "uuid";
import winston from "winston";

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || "info",
  format: winston.format.json(),
  transports: [new winston.transports.Console()],
});

const db = new Database("database/accounts.db");

// Event tracking
export function trackEvent(userId, eventType, eventData = {}, req = null) {
  try {
    const id = uuidv4();
    const ipAddress = req?.ip || "unknown";
    const userAgent = req?.get("user-agent") || "unknown";

    const stmt = db.prepare(`
      INSERT INTO analytics_events (id, user_id, event_type, event_data, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      id,
      userId,
      eventType,
      JSON.stringify(eventData),
      ipAddress,
      userAgent
    );

    logger.info(`📊 Event tracked: ${eventType}`, { userId, eventData });
  } catch (error) {
    logger.error("Error tracking event:", error);
  }
}

// Transaction tracking
export function logTransaction(userId, fromAccount, toAccount, amount, txId, txType = "transfer") {
  try {
    const id = uuidv4();

    const stmt = db.prepare(`
      INSERT INTO transaction_logs (id, user_id, from_account, to_account, amount, transaction_id, tx_type)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(id, userId, fromAccount, toAccount, amount, txId, txType);

    logger.info(`💳 Transaction logged: ${txId}`, { userId, amount });
    return id;
  } catch (error) {
    logger.error("Error logging transaction:", error);
  }
}

// Update transaction status
export function updateTransactionStatus(txId, status, completedAt = null) {
  try {
    const stmt = db.prepare(`
      UPDATE transaction_logs 
      SET status = ?, completed_at = ?
      WHERE id = ?
    `);

    stmt.run(status, completedAt || new Date().toISOString(), txId);
  } catch (error) {
    logger.error("Error updating transaction status:", error);
  }
}

// Get user analytics
export function getUserAnalytics(userId, daysBack = 30) {
  try {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    // Total transactions
    const txStmt = db.prepare(`
      SELECT COUNT(*) as total, SUM(amount) as volume, AVG(amount) as avg_amount
      FROM transaction_logs
      WHERE user_id = ? AND created_at >= ?
    `);
    const txData = txStmt.get(userId, startDate.toISOString());

    // Transactions by type
    const txTypeStmt = db.prepare(`
      SELECT tx_type, COUNT(*) as count, SUM(amount) as volume
      FROM transaction_logs
      WHERE user_id = ? AND created_at >= ?
      GROUP BY tx_type
    `);
    const txByType = txTypeStmt.all(userId, startDate.toISOString());

    // Daily breakdown
    const dailyStmt = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as tx_count,
        SUM(amount) as volume
      FROM transaction_logs
      WHERE user_id = ? AND created_at >= ?
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `);
    const dailyData = dailyStmt.all(userId, startDate.toISOString());

    // Account count
    const accountStmt = db.prepare(`
      SELECT COUNT(*) as total FROM stored_accounts WHERE user_id = ?
    `);
    const accountData = accountStmt.get(userId);

    // Token count
    const tokenStmt = db.prepare(`
      SELECT COUNT(*) as total FROM tokens WHERE user_id = ?
    `);
    const tokenData = tokenStmt.get(userId);

    return {
      period: `Last ${daysBack} days`,
      transactions: {
        total: txData.total || 0,
        volume: txData.volume || 0,
        avgAmount: txData.avg_amount || 0,
        byType: txByType,
      },
      accounts: accountData.total || 0,
      tokens: tokenData.total || 0,
      dailyBreakdown: dailyData,
    };
  } catch (error) {
    logger.error("Error getting user analytics:", error);
    return null;
  }
}

// Get platform analytics
export function getPlatformAnalytics(daysBack = 30) {
  try {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    // Total users
    const userStmt = db.prepare(`
      SELECT COUNT(DISTINCT user_id) as total_users
      FROM transaction_logs
      WHERE created_at >= ?
    `);
    const userData = userStmt.get(startDate.toISOString());

    // Total transactions
    const txStmt = db.prepare(`
      SELECT 
        COUNT(*) as total_tx,
        SUM(amount) as total_volume,
        AVG(amount) as avg_tx,
        MIN(amount) as min_tx,
        MAX(amount) as max_tx
      FROM transaction_logs
      WHERE created_at >= ?
    `);
    const txData = txStmt.get(startDate.toISOString());

    // Daily summary
    const summaryStmt = db.prepare(`
      SELECT 
        DATE(created_at) as date,
        COUNT(DISTINCT user_id) as active_users,
        COUNT(*) as tx_count,
        SUM(amount) as volume
      FROM transaction_logs
      WHERE created_at >= ?
      GROUP BY DATE(created_at)
      ORDER BY date DESC
    `);
    const summaryData = summaryStmt.all(startDate.toISOString());

    // Top users
    const topUsersStmt = db.prepare(`
      SELECT 
        user_id,
        COUNT(*) as tx_count,
        SUM(amount) as volume
      FROM transaction_logs
      WHERE created_at >= ?
      GROUP BY user_id
      ORDER BY volume DESC
      LIMIT 10
    `);
    const topUsers = topUsersStmt.all(startDate.toISOString());

    return {
      period: `Last ${daysBack} days`,
      activeUsers: userData.total_users || 0,
      transactions: {
        total: txData.total_tx || 0,
        totalVolume: txData.total_volume || 0,
        avgSize: txData.avg_tx || 0,
        minSize: txData.min_tx || 0,
        maxSize: txData.max_tx || 0,
      },
      dailySummary: summaryData,
      topUsers: topUsers,
    };
  } catch (error) {
    logger.error("Error getting platform analytics:", error);
    return null;
  }
}

// Event analytics
export function getEventAnalytics(daysBack = 30) {
  try {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - daysBack);

    const stmt = db.prepare(`
      SELECT 
        event_type,
        COUNT(*) as count,
        COUNT(DISTINCT user_id) as unique_users
      FROM analytics_events
      WHERE timestamp >= ?
      GROUP BY event_type
      ORDER BY count DESC
    `);

    const events = stmt.all(startDate.toISOString());

    return events;
  } catch (error) {
    logger.error("Error getting event analytics:", error);
    return [];
  }
}

export default {
  trackEvent,
  logTransaction,
  updateTransactionStatus,
  getUserAnalytics,
  getPlatformAnalytics,
  getEventAnalytics,
};