export class BatchProcessor {
  constructor(timeout = 100, batchSize = 100) {
    this.timeout = timeout;
    this.batchSize = batchSize;
    this.queue = [];
    this.timerId = null;
  }

  add(query) {
    return new Promise((resolve, reject) => {
      this.queue.push({ query, resolve, reject });

      if (this.queue.length >= this.batchSize) {
        this.flush();
      } else if (!this.timerId) {
        this.timerId = setTimeout(() => this.flush(), this.timeout);
      }
    });
  }

  async flush() {
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }

    if (this.queue.length === 0) return;

    const batch = this.queue.splice(0, this.batchSize);

    try {
      // Ejecutar queries en paralelo
      const results = await Promise.all(
        batch.map((item) => item.query())
      );

      batch.forEach((item, index) => {
        item.resolve(results[index]);
      });
    } catch (error) {
      batch.forEach((item) => {
        item.reject(error);
      });
    }
  }
}

export const transactionBatcher = new BatchProcessor(50, 50);