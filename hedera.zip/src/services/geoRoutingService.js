import { cfClient } from "../config/cloudflare.js";

export class GeoRoutingService {
  constructor() {
    this.regionMap = {
      NA: "https://us-origin.herokuapp.com",
      SA: "https://us-origin.herokuapp.com",
      EU: "https://eu-origin.herokuapp.com",
      AF: "https://eu-origin.herokuapp.com",
      AS: "https://asia-origin.herokuapp.com",
      OC: "https://asia-origin.herokuapp.com",
    };

    this.regionNames = {
      NA: "North America",
      SA: "South America",
      EU: "Europe",
      AF: "Africa",
      AS: "Asia",
      OC: "Oceania",
    };
  }

  /**
   * Get closest origin based on country
   */
  getOriginForCountry(countryCode) {
    // Country to continent mapping
    const continentMap = {
      // North America
      US: "NA",
      CA: "NA",
      MX: "NA",
      // South America
      BR: "SA",
      AR: "SA",
      CL: "SA",
      // Europe
      GB: "EU",
      FR: "EU",
      DE: "EU",
      IT: "EU",
      ES: "EU",
      NL: "EU",
      // Africa
      ZA: "AF",
      EG: "AF",
      NG: "AF",
      // Asia
      JP: "AS",
      CN: "AS",
      IN: "AS",
      SG: "AS",
      AU: "OC",
    };

    const continent = continentMap[countryCode] || "NA";
    return this.regionMap[continent];
  }

  /**
   * Create CloudFlare geo-routing rules
   */
  async setupGeoRouting() {
    try {
      const rules = [
        {
          name: "Route EU to EU Origin",
          expression: 'cf.continent == "EU"',
          origin: "https://eu-origin.herokuapp.com",
        },
        {
          name: "Route ASIA to ASIA Origin",
          expression: 'cf.continent == "AS"',
          origin: "https://asia-origin.herokuapp.com",
        },
        {
          name: "Route Americas to US Origin",
          expression: 'cf.continent == "NA" or cf.continent == "SA"',
          origin: "https://us-origin.herokuapp.com",
        },
      ];

      for (const rule of rules) {
        console.log(`Setting up geo-routing: ${rule.name}`);
        // Create origin rule via CloudFlare API
        await cfClient.createPageRule([rule.expression], [
          {
            id: "origin_url",
            value: rule.origin,
          },
        ]);
      }

      console.log("✅ Geo-routing rules configured");
    } catch (error) {
      console.error("Error setting up geo-routing:", error);
    }
  }

  /**
   * Get latency metrics for each region
   */
  async getLatencyMetrics(req) {
    const country = req.headers.get("cf-ipcountry") || "US";
    const continent = req.headers.get("cf-continent") || "NA";
    const colo = req.headers.get("cf-ray")?.split("-")[1] || "unknown";

    return {
      country,
      continent,
      colo,
      origin: this.getOriginForCountry(country),
      region: this.regionNames[continent],
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Monitor region performance
   */
  async monitorRegions() {
    const regions = [
      { name: "US", url: "https://us-origin.herokuapp.com/api/health" },
      { name: "EU", url: "https://eu-origin.herokuapp.com/api/health" },
      { name: "ASIA", url: "https://asia-origin.herokuapp.com/api/health" },
    ];

    const results = await Promise.all(
      regions.map(async (region) => {
        const start = Date.now();
        try {
          const response = await fetch(region.url, { method: "HEAD" });
          const latency = Date.now() - start;
          return {
            region: region.name,
            status: response.status,
            latency,
            healthy: response.status === 200,
          };
        } catch (error) {
          return {
            region: region.name,
            status: 0,
            latency: Date.now() - start,
            healthy: false,
            error: error.message,
          };
        }
      })
    );

    return results;
  }
}

export const geoRoutingService = new GeoRoutingService();