import Database from "better-sqlite3";
import { encryptPrivateKey, decryptPrivateKey } from "../utils/encryption.js";
import { v4 as uuidv4 } from "uuid";

const db = new Database("database/accounts.db");

// Inicializar tabla
db.exec(`
    CREATE TABLE IF NOT EXISTS stored_accounts (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        account_id TEXT NOT NULL UNIQUE,
        encrypted_private_key TEXT NOT NULL,
        public_key TEXT,
        balance REAL DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    );
    
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
`);

export function storeAccount(userId, accountId, privateKey, publicKey, masterPassword) {
    const encryptedKey = encryptPrivateKey(privateKey, masterPassword);
    const id = uuidv4();
    
    const stmt = db.prepare(`
        INSERT INTO stored_accounts (id, user_id, account_id, encrypted_private_key, public_key)
        VALUES (?, ?, ?, ?, ?)
    `);
    
    stmt.run(id, userId, accountId, encryptedKey, publicKey);
    return id;
}

export function getAccount(userId, accountId, masterPassword) {
    const stmt = db.prepare(`
        SELECT * FROM stored_accounts 
        WHERE user_id = ? AND account_id = ?
    `);
    
    const account = stmt.get(userId, accountId);
    
    if (!account) return null;
    
    const decryptedKey = decryptPrivateKey(account.encrypted_private_key, masterPassword);
    return { ...account, private_key: decryptedKey };
}

export function listUserAccounts(userId) {
    const stmt = db.prepare(`
        SELECT id, account_id, public_key, balance, created_at 
        FROM stored_accounts 
        WHERE user_id = ?
    `);
    
    return stmt.all(userId);
}

export function updateAccountBalance(accountId, balance) {
    const stmt = db.prepare(`
        UPDATE stored_accounts 
        SET balance = ?, updated_at = CURRENT_TIMESTAMP
        WHERE account_id = ?
    `);
    
    stmt.run(balance, accountId);
}