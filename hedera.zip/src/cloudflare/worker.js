/**
 * CloudFlare Worker
 * - Runs on Edge (< 1ms latency)
 * - Handles requests near users
 * - Custom caching logic
 * - Rate limiting
 */

// Este archivo se deploye a CloudFlare Workers
export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Health check - respond immediately
    if (url.pathname === "/api/health") {
      return new Response(
        JSON.stringify({
          status: "ok",
          timestamp: new Date().toISOString(),
          edge: true,
        }),
        {
          headers: {
            "Content-Type": "application/json",
            "Cache-Control": "public, max-age=60",
            "X-Edge": "true",
          },
        }
      );
    }

    // Cache key optimization
    const cacheKey = new Request(url.toString(), {
      method: "GET",
    });
    const cache = caches.default;

    // Check cache first
    let response = await cache.match(cacheKey);
    if (response) {
      return new Response(response.body, {
        ...response,
        headers: {
          ...Object.fromEntries(response.headers),
          "X-Cache": "HIT",
        },
      });
    }

    // Rate limiting
    const clientIp = request.headers.get("cf-connecting-ip");
    const rateKey = `rate:${clientIp}`;
    const count = await env.RATE_LIMITER.get(rateKey);

    if (count && parseInt(count) > 100) {
      return new Response("Rate limited", { status: 429 });
    }

    await env.RATE_LIMITER.put(
      rateKey,
      (parseInt(count) || 0) + 1,
      { expirationTtl: 60 }
    );

    // Geo-routing
    const continent = request.headers.get("cf-ipcountry");
    let origin = env.ORIGIN_US;

    if (continent === "EU") {
      origin = env.ORIGIN_EU;
    } else if (continent === "AS") {
      origin = env.ORIGIN_ASIA;
    }

    // Forward request to origin
    const originResponse = await fetch(`${origin}${url.pathname}`, {
      method: request.method,
      headers: request.headers,
      body: request.body,
    });

    // Cache successful responses
    if (originResponse.status === 200) {
      const ttl = url.pathname.startsWith("/api") ? 300 : 3600;
      const cacheHeaders = new Headers(originResponse.headers);
      cacheHeaders.set("Cache-Control", `public, max-age=${ttl}`);

      const cachedResponse = new Response(originResponse.body, {
        status: originResponse.status,
        statusText: originResponse.statusText,
        headers: cacheHeaders,
      });

      await cache.put(cacheKey, cachedResponse.clone());
      return cachedResponse;
    }

    return new Response(originResponse.body, {
      ...originResponse,
      headers: {
        ...Object.fromEntries(originResponse.headers),
        "X-Cache": "MISS",
      },
    });
  },

  // Scheduled handler (cron jobs)
  async scheduled(event, env, ctx) {
    // Purge cache every hour
    if (event.cron === "0 * * * *") {
      const response = await fetch("https://api.cloudflare.com/client/v4/zones/purge_cache", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${env.CLOUDFLARE_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          tags: ["hourly"],
        }),
      });
      console.log("Cache purged:", response.status);
    }
  },
};