import express from "express";
import { verifyToken } from "../middleware/auth.js";
import { createAccountLimiter } from "../middleware/rateLimit.js";
import * as accountService from "../services/accountService.js";

const router = express.Router();

router.post("/create", verifyToken, createAccountLimiter, async (req, res) => {
    try {
        const { masterPassword } = req.body;
        
        if (!masterPassword || masterPassword.length < 12) {
            return res.status(400).json({ 
                error: "Master password must be at least 12 characters" 
            });
        }

        // Lógica para crear cuenta con seguridad
        const account = await createSecureAccount(req.user.userId, masterPassword);
        res.json(account);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

router.get("/list", verifyToken, async (req, res) => {
    try {
        const accounts = accountService.listUserAccounts(req.user.userId);
        res.json({ accounts });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;