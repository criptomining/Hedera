import express from "express";
import { verifyToken } from "../middleware/auth.js";
import { transactionLimiter } from "../middleware/rateLimit.js";
import * as transactionController from "../controllers/transactionController.js";

const router = express.Router();

router.post("/transfer", verifyToken, transactionLimiter, async (req, res) => {
    try {
        const { fromAccountId, toAccountId, amount, masterPassword } = req.body;
        
        // Obtener la cuenta del usuario
        const account = await accountService.getAccount(
            req.user.userId,
            fromAccountId,
            masterPassword
        );
        
        if (!account) {
            return res.status(404).json({ error: "Account not found" });
        }
        
        // Ejecutar transferencia
        const result = await transactionController.transferHbar(
            client,
            fromAccountId,
            toAccountId,
            new Hbar(amount)
        );
        
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;