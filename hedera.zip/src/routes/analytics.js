import express from "express";
import { verifyToken } from "../middleware/auth.js";
import * as analyticsService from "../services/analyticsService.js";

const router = express.Router();

// User analytics
router.get("/user", verifyToken, (req, res) => {
  try {
    const daysBack = parseInt(req.query.days) || 30;
    const analytics = analyticsService.getUserAnalytics(req.user.userId, daysBack);

    res.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Platform analytics (admin only)
router.get("/platform", verifyToken, (req, res) => {
  try {
    // Verify admin role (add to user JWT)
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }

    const daysBack = parseInt(req.query.days) || 30;
    const analytics = analyticsService.getPlatformAnalytics(daysBack);

    res.json({
      success: true,
      data: analytics,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

// Event analytics
router.get("/events", verifyToken, (req, res) => {
  try {
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }

    const daysBack = parseInt(req.query.days) || 30;
    const events = analyticsService.getEventAnalytics(daysBack);

    res.json({
      success: true,
      data: events,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

export default router;