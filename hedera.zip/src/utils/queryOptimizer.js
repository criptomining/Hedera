import Database from "better-sqlite3";

const db = new Database("database/accounts.db");

// Enable WAL mode para mejor concurrency
db.pragma("journal_mode = WAL");
db.pragma("synchronous = NORMAL");
db.pragma("cache_size = -64000"); // 64MB cache
db.pragma("foreign_keys = ON");
db.pragma("temp_store = MEMORY");

// Prepared statements cache
const preparedStatements = new Map();

export function getStatement(sql) {
  if (!preparedStatements.has(sql)) {
    preparedStatements.set(sql, db.prepare(sql));
  }
  return preparedStatements.get(sql);
}

// Connection pooling simulation
export class QueryPool {
  constructor(maxConnections = 5) {
    this.maxConnections = maxConnections;
    this.activeQueries = 0;
    this.queue = [];
  }

  async execute(query, params = []) {
    while (this.activeQueries >= this.maxConnections) {
      await new Promise((resolve) => this.queue.push(resolve));
    }

    this.activeQueries++;

    try {
      const stmt = getStatement(query);
      return stmt.all(...params);
    } finally {
      this.activeQueries--;
      const resolve = this.queue.shift();
      if (resolve) resolve();
    }
  }

  async executeSingle(query, params = []) {
    while (this.activeQueries >= this.maxConnections) {
      await new Promise((resolve) => this.queue.push(resolve));
    }

    this.activeQueries++;

    try {
      const stmt = getStatement(query);
      return stmt.get(...params);
    } finally {
      this.activeQueries--;
      const resolve = this.queue.shift();
      if (resolve) resolve();
    }
  }
}

export const queryPool = new QueryPool(5);

// Batch operations
export async function batchInsert(table, records) {
  const columns = Object.keys(records[0]);
  const placeholders = columns.map(() => "?").join(",");
  const sql = `INSERT INTO ${table} (${columns.join(",")}) VALUES (${placeholders})`;

  db.transaction(() => {
    const stmt = db.prepare(sql);
    for (const record of records) {
      stmt.run(...columns.map((col) => record[col]));
    }
  })();
}

// Index analysis
export function analyzeIndexes() {
  const analyze = db.prepare("ANALYZE").all();
  const indexes = db.prepare("SELECT * FROM sqlite_stat1").all();
  return indexes;
}