import cluster from "cluster";
import os from "os";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export function setupCluster(callback) {
  const numCPUs = os.cpus().length;
  const numWorkers = process.env.WORKERS || numCPUs;

  if (cluster.isMaster) {
    console.log(`🚀 Master process ${process.pid} starting...`);
    console.log(`👷 Creating ${numWorkers} workers...`);

    // Fork workers
    for (let i = 0; i < numWorkers; i++) {
      cluster.fork();
    }

    // Handle worker death
    cluster.on("exit", (worker, code, signal) => {
      console.log(
        `💀 Worker ${worker.process.pid} died (${signal || code}). Restarting...`
      );
      cluster.fork();
    });

    // Display cluster info
    console.log(`✅ Cluster setup complete with ${numWorkers} workers`);
  } else {
    console.log(`⚙️ Worker process ${process.pid} started`);
    callback();
  }
}