import { Worker } from "worker_threads";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export class WorkerPool {
  constructor(workerScript, poolSize = 4) {
    this.workerScript = workerScript;
    this.poolSize = poolSize;
    this.workers = [];
    this.queue = [];
    this.activeWorkers = new Set();

    this.initializePool();
  }

  initializePool() {
    for (let i = 0; i < this.poolSize; i++) {
      const worker = new Worker(this.workerScript);
      this.workers.push({
        worker,
        busy: false,
      });
    }
  }

  async run(data) {
    return new Promise((resolve, reject) => {
      const task = { data, resolve, reject };

      const availableWorker = this.workers.find((w) => !w.busy);

      if (availableWorker) {
        this.executeTask(availableWorker, task);
      } else {
        this.queue.push(task);
      }
    });
  }

  executeTask(workerWrapper, task) {
    workerWrapper.busy = true;
    this.activeWorkers.add(workerWrapper);

    workerWrapper.worker.once("message", (result) => {
      task.resolve(result);
      this.taskComplete(workerWrapper);
    });

    workerWrapper.worker.once("error", (error) => {
      task.reject(error);
      this.taskComplete(workerWrapper);
    });

    workerWrapper.worker.postMessage(task.data);
  }

  taskComplete(workerWrapper) {
    workerWrapper.busy = false;
    this.activeWorkers.delete(workerWrapper);

    if (this.queue.length > 0) {
      const task = this.queue.shift();
      this.executeTask(workerWrapper, task);
    }
  }

  terminate() {
    this.workers.forEach((w) => w.worker.terminate());
  }

  getStats() {
    return {
      poolSize: this.poolSize,
      activeWorkers: this.activeWorkers.size,
      queueLength: this.queue.length,
    };
  }
}