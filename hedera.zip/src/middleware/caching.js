import { cacheGet, cacheSet, cacheDel } from "../config/redis.js";

export function cacheMiddleware(ttl = 300) {
  return async (req, res, next) => {
    // Solo cachear GET requests
    if (req.method !== "GET") {
      return next();
    }

    const cacheKey = `cache:${req.user?.userId}:${req.originalUrl}`;

    try {
      const cachedData = await cacheGet(cacheKey);
      if (cachedData) {
        res.set("X-Cache", "HIT");
        return res.json(JSON.parse(cachedData));
      }
    } catch (error) {
      console.warn("Cache retrieval failed:", error);
    }

    // Interceptar res.json
    const originalJson = res.json.bind(res);
    res.json = function (data) {
      res.set("X-Cache", "MISS");
      
      // Cachear la respuesta
      cacheSet(cacheKey, data, ttl).catch(console.error);
      
      return originalJson(data);
    };

    next();
  };
}

export function invalidateCache(pattern) {
  return async (req, res, next) => {
    // Ejecutar después de la respuesta
    res.on("finish", async () => {
      if (res.statusCode < 400) {
        try {
          await cacheDel(pattern);
        } catch (error) {
          console.warn("Cache invalidation failed:", error);
        }
      }
    });

    next();
  };
}

export function cacheControl(maxAge = 3600) {
  return (req, res, next) => {
    res.set("Cache-Control", `public, max-age=${maxAge}`);
    res.set("ETag", `W/"${Date.now()}"`);
    next();
  };
}