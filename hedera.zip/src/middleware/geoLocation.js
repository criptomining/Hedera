import { geoRoutingService } from "../services/geoRoutingService.js";

export function geoLocationMiddleware(req, res, next) {
  // CloudFlare headers
  const country = req.headers.get("cf-ipcountry") || "US";
  const continent = req.headers.get("cf-continent") || "NA";
  const colo = req.headers.get("cf-ray")?.split("-")?.[1] || "unknown";
  const clientIp = req.headers.get("cf-connecting-ip") || req.ip;
  const asn = req.headers.get("cf-asn") || "unknown";
  const timezone = req.headers.get("cf-timezone") || "UTC";

  // Attach to request
  req.geo = {
    country,
    continent,
    colo,
    clientIp,
    asn,
    timezone,
    origin: geoRoutingService.getOriginForCountry(country),
  };

  // Add headers to response
  res.set("X-Geo-Country", country);
  res.set("X-Geo-Continent", continent);
  res.set("X-Geo-Colo", colo);

  next();
}

/**
 * Route based on geography
 */
export function geoBasedRouting(req, res, next) {
  const continent = req.geo?.continent || "NA";

  // Example: Serve different content based on region
  if (continent === "EU") {
    res.set("X-Server-Region", "EU");
    // Add GDPR compliance headers
    res.set("X-GDPR-Compliant", "true");
  } else if (continent === "AS") {
    res.set("X-Server-Region", "ASIA");
  } else {
    res.set("X-Server-Region", "US");
  }

  next();
}

/**
 * Latency-based load balancing
 */
export async function latencyBasedLoadBalancing(req, res, next) {
  const regionMetrics = await geoRoutingService.monitorRegions();
  
  // Choose origin with lowest latency
  const bestRegion = regionMetrics.reduce((best, current) => {
    return current.latency < best.latency ? current : best;
  });

  req.selectedOrigin = {
    region: bestRegion.region,
    latency: bestRegion.latency,
  };

  res.set("X-Selected-Region", bestRegion.region);
  res.set("X-Latency-Ms", bestRegion.latency.toString());

  next();
}