import { cfClient } from "../config/cloudflare.js";

export class CloudFlareAnalytics {
  constructor() {
    this.metrics = {
      requests: 0,
      cacheHits: 0,
      cacheMisses: 0,
      threats: 0,
      bandwidth: 0,
      regions: {},
    };
  }

  middleware() {
    return (req, res, next) => {
      const country = req.headers.get("cf-ipcountry") || "US";
      const continent = req.headers.get("cf-continent") || "NA";
      const cacheStatus = req.headers.get("cf-cache-status") || "MISS";
      const threatScore = parseInt(req.headers.get("cf-threat-score") || "0");

      // Update metrics
      this.metrics.requests++;

      if (cacheStatus === "HIT") {
        this.metrics.cacheHits++;
      } else {
        this.metrics.cacheMisses++;
      }

      if (threatScore > 50) {
        this.metrics.threats++;
      }

      if (!this.metrics.regions[country]) {
        this.metrics.regions[country] = {
          requests: 0,
          cacheHits: 0,
          cacheMisses: 0,
        };
      }

      this.metrics.regions[country].requests++;
      if (cacheStatus === "HIT") {
        this.metrics.regions[country].cacheHits++;
      } else {
        this.metrics.regions[country].cacheMisses++;
      }

      // Track response
      res.on("finish", () => {
        const responseTime = Date.now();
        this.recordRequest({
          country,
          continent,
          cacheStatus,
          threatScore,
          statusCode: res.statusCode,
          responseTime,
        });
      });

      next();
    };
  }

  recordRequest(data) {
    // Store in database for later analysis
    console.log(`📊 Request: ${data.country} | Cache: ${data.cacheStatus} | Threat: ${data.threatScore}`);
  }

  getMetrics() {
    const totalRequests = this.metrics.requests;
    const cacheHitRate = (
      (this.metrics.cacheHits / (this.metrics.requests || 1)) * 100
    ).toFixed(2);

    return {
      totalRequests,
      cacheHits: this.metrics.cacheHits,
      cacheMisses: this.metrics.cacheMisses,
      cacheHitRate: `${cacheHitRate}%`,
      threatsDetected: this.metrics.threats,
      threatRate: ((this.metrics.threats / totalRequests) * 100).toFixed(2),
      byRegion: this.metrics.regions,
    };
  }

  async fetchCloudFlareAnalytics() {
    try {
      const since = new Date();
      since.setDate(since.getDate() - 1);

      const until = new Date();

      const analytics = await cfClient.getAnalytics(
        Math.floor(since.getTime() / 1000),
        Math.floor(until.getTime() / 1000)
      );

      return {
        period: {
          start: since.toISOString(),
          end: until.toISOString(),
        },
        requests: analytics.totals.requests,
        bandwidth: analytics.totals.bandwidth,
        uncached: analytics.totals.uncached,
        cacheHitRate: (
          ((analytics.totals.requests - analytics.totals.uncached) /
            analytics.totals.requests) *
          100
        ).toFixed(2),
      };
    } catch (error) {
      console.error("Error fetching CloudFlare analytics:", error);
      return null;
    }
  }

  async reportAnalytics() {
    const cf = await this.fetchCloudFlareAnalytics();
    return {
      internal: this.getMetrics(),
      cloudflare: cf,
    };
  }
}

export const cfAnalytics = new CloudFlareAnalytics();