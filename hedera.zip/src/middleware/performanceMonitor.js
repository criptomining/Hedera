import os from "os";
import { performance } from "perf_hooks";

export class PerformanceMonitor {
  constructor() {
    this.metrics = {
      requestCount: 0,
      totalResponseTime: 0,
      slowRequests: [],
      errors: 0,
      memoryUsage: [],
      cpuUsage: [],
    };
    this.startTime = Date.now();
  }

  middleware() {
    return (req, res, next) => {
      const startTime = performance.now();

      res.on("finish", () => {
        const duration = performance.now() - startTime;
        this.metrics.requestCount++;
        this.metrics.totalResponseTime += duration;

        // Registrar requests lentos (> 1000ms)
        if (duration > 1000) {
          this.metrics.slowRequests.push({
            method: req.method,
            url: req.originalUrl,
            duration,
            timestamp: new Date(),
          });
        }

        if (res.statusCode >= 400) {
          this.metrics.errors++;
        }
      });

      next();
    };
  }

  recordMemory() {
    const memory = process.memoryUsage();
    this.metrics.memoryUsage.push({
      timestamp: Date.now(),
      heapUsed: memory.heapUsed / 1024 / 1024, // MB
      heapTotal: memory.heapTotal / 1024 / 1024,
      external: memory.external / 1024 / 1024,
      rss: memory.rss / 1024 / 1024,
    });

    // Keep only last 60 entries
    if (this.metrics.memoryUsage.length > 60) {
      this.metrics.memoryUsage.shift();
    }
  }

  recordCPU() {
    const cpus = os.cpus();
    const loadAvg = os.loadavg();
    
    this.metrics.cpuUsage.push({
      timestamp: Date.now(),
      loadAverage: loadAvg[0],
      cores: cpus.length,
    });

    if (this.metrics.cpuUsage.length > 60) {
      this.metrics.cpuUsage.shift();
    }
  }

  getMetrics() {
    return {
      uptime: (Date.now() - this.startTime) / 1000,
      requestCount: this.metrics.requestCount,
      avgResponseTime: this.metrics.requestCount > 0 
        ? this.metrics.totalResponseTime / this.metrics.requestCount 
        : 0,
      errorRate: this.metrics.requestCount > 0 
        ? (this.metrics.errors / this.metrics.requestCount * 100).toFixed(2) 
        : 0,
      slowRequests: this.metrics.slowRequests.slice(-10),
      memory: this.metrics.memoryUsage[this.metrics.memoryUsage.length - 1],
      cpu: this.metrics.cpuUsage[this.metrics.cpuUsage.length - 1],
    };
  }

  reset() {
    this.metrics = {
      requestCount: 0,
      totalResponseTime: 0,
      slowRequests: [],
      errors: 0,
      memoryUsage: [],
      cpuUsage: [],
    };
  }
}

export const monitor = new PerformanceMonitor();

// Recolectar métricas cada 10 segundos
setInterval(() => {
  monitor.recordMemory();
  monitor.recordCPU();
}, 10000);