/**
 * Mobile & PWA Optimization Middleware
 */

export function mobileOptimization(req, res, next) {
  const userAgent = req.get("user-agent") || "";
  const isMobile = /mobile|android|iphone/i.test(userAgent);

  // Attach device info to request
  req.device = {
    isMobile,
    isTablet: /tablet|ipad/i.test(userAgent),
    isIOS: /iphone|ipad/i.test(userAgent),
    isAndroid: /android/i.test(userAgent),
    userAgent,
  };

  // Add mobile-specific headers
  if (isMobile) {
    res.set("X-UA-Compatible", "IE=edge");
    res.set("X-Mobile-Optimized", "true");
  }

  next();
}

/**
 * Serve optimized assets based on device
 */
export function serveOptimizedAssets(req, res, next) {
  if (req.device.isMobile) {
    // Reduce image quality for mobile
    res.set("X-Image-Optimization", "mobile");
  }

  next();
}

/**
 * PWA Installation Tracking
 */
export function trackPWAInstall(req, res, next) {
  res.on("finish", () => {
    if (req.path === "/" && req.device.isMobile) {
      // Log PWA access
      console.log("📱 Mobile PWA access from:", req.ip);
    }
  });

  next();
}