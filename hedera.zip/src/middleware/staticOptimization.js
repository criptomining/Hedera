import express from "express";
import sharp from "sharp";
import path from "path";

export function setupStaticOptimization(app) {
  // Serve static files with caching
  app.use(
    express.static("public", {
      maxAge: "1d",
      etag: false,
    })
  );

  // Image optimization endpoint
  app.get("/api/image-optimize", async (req, res) => {
    const { url, width, height, format } = req.query;

    try {
      let transform = sharp(url);

      if (width || height) {
        transform = transform.resize(parseInt(width), parseInt(height), {
          fit: "cover",
          position: "center",
        });
      }

      if (format) {
        transform = transform.toFormat(format, { quality: 80 });
      }

      const buffer = await transform.toBuffer();
      res.type(format || "webp");
      res.send(buffer);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  // Serve WebP with fallback
  app.use((req, res, next) => {
    if (req.accepts("image/webp") && req.path.endsWith(".jpg")) {
      const webpPath = req.path.replace(/\.jpg$/, ".webp");
      res.set("Vary", "Accept");
      // Serve webp if exists
    }
    next();
  });
}