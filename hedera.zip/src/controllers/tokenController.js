import {
    TokenCreateTransaction,
    TokenTransferTransaction,
    TokenAssociateTransaction,
    TokenType,
    TokenSupplyType,
    AccountId,
} from "@hashgraph/sdk";

export async function createFungibleToken(client, tokenName, tokenSymbol, initialSupply) {
    try {
        const transaction = new TokenCreateTransaction()
            .setTokenName(tokenName)
            .setTokenSymbol(tokenSymbol)
            .setDecimals(2)
            .setInitialSupply(initialSupply)
            .setTokenType(TokenType.FUNGIBLE_COMMON)
            .setSupplyType(TokenSupplyType.FINITE)
            .setMaxSupply(initialSupply * 2)
            .setTreasuryAccountId(client.operatorAccountId)
            .freezeWith(client);

        const signTx = await transaction.sign(client.operatorKey);
        const txResponse = await signTx.execute(client);
        const receipt = await txResponse.getReceipt(client);

        return {
            success: true,
            tokenId: receipt.tokenId.toString(),
            transactionId: txResponse.transactionId.toString(),
        };
    } catch (error) {
        throw new Error(`Token creation failed: ${error.message}`);
    }
}

export async function transferToken(client, tokenId, fromAccountId, toAccountId, amount) {
    try {
        // Primero, asociar el token a la cuenta receptora si no lo está
        const associateTransaction = new TokenAssociateTransaction()
            .setAccountId(AccountId.fromString(toAccountId))
            .addTokenId(tokenId)
            .freezeWith(client);

        // Transferir el token
        const transferTransaction = new TokenTransferTransaction()
            .addTokenTransfer(tokenId, fromAccountId, -amount)
            .addTokenTransfer(tokenId, toAccountId, amount)
            .freezeWith(client);

        const signTx = await transferTransaction.sign(client.operatorKey);
        const txResponse = await signTx.execute(client);
        const receipt = await txResponse.getReceipt(client);

        return {
            success: true,
            transactionId: txResponse.transactionId.toString(),
            status: receipt.status.toString(),
        };
    } catch (error) {
        throw new Error(`Token transfer failed: ${error.message}`);
    }
}