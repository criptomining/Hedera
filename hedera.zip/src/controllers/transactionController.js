import {
    TransferTransaction,
    AccountBalanceQuery,
} from "@hashgraph/sdk";

export async function transferHbar(client, fromAccountId, toAccountId, amount) {
    try {
        const transfer = new TransferTransaction()
            .addHbarTransfer(fromAccountId, amount.negated())
            .addHbarTransfer(toAccountId, amount)
            .freezeWith(client);

        const signTx = await transfer.sign(client.operatorKey);
        const txResponse = await signTx.execute(client);
        const receipt = await txResponse.getReceipt(client);

        return {
            success: true,
            transactionId: txResponse.transactionId.toString(),
            status: receipt.status.toString(),
        };
    } catch (error) {
        throw new Error(`Transfer failed: ${error.message}`);
    }
}

export async function getBalance(client, accountId) {
    try {
        const balance = await new AccountBalanceQuery()
            .setAccountId(accountId)
            .execute(client);

        return balance.hbars.toString();
    } catch (error) {
        throw new Error(`Balance query failed: ${error.message}`);
    }
}