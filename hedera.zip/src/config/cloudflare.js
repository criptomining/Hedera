/**
 * CloudFlare Configuration
 * - Global CDN & Caching
 * - DDoS Protection
 * - Workers for Edge Computing
 * - Analytics & Monitoring
 */

export const cloudflareConfig = {
  // CloudFlare API
  zone_id: process.env.CLOUDFLARE_ZONE_ID,
  api_token: process.env.CLOUDFLARE_API_TOKEN,
  account_id: process.env.CLOUDFLARE_ACCOUNT_ID,

  // Cache Strategy
  cache: {
    rules: [
      {
        path: "/api/*",
        ttl: 300, // 5 minutos
        cache_level: "cache_everything",
      },
      {
        path: "/public/*",
        ttl: 86400, // 1 día
        cache_level: "cache_everything",
      },
      {
        path: "/dashboard.html",
        ttl: 3600, // 1 hora
        cache_level: "cache_everything",
      },
    ],
  },

  // Geo-Blocking & Routing
  geo_routing: {
    enabled: true,
    rules: [
      {
        continent: "NA", // North America
        origin: "us-origin.herokuapp.com",
        priority: 1,
      },
      {
        continent: "EU", // Europe
        origin: "eu-origin.herokuapp.com",
        priority: 2,
      },
      {
        continent: "AS", // Asia
        origin: "asia-origin.herokuapp.com",
        priority: 3,
      },
    ],
  },

  // Performance
  performance: {
    minify: {
      javascript: true,
      css: true,
      html: true,
    },
    rocket_loader: true,
    lazy_load_images: true,
    prefetch_preload: true,
  },

  // Security
  security: {
    ddos_protection: "high",
    waf_enabled: true,
    bot_fight_mode: true,
    challenge_ttl: 900,
  },

  // Workers (Edge Computing)
  workers: {
    enabled: true,
    routes: [
      "/api/analytics/*",
      "/api/health",
      "/api/cache-stats",
    ],
  },
};

/**
 * CloudFlare API Client
 */
export class CloudFlareClient {
  constructor(zoneId, apiToken) {
    this.zoneId = zoneId;
    this.apiToken = apiToken;
    this.baseUrl = "https://api.cloudflare.com/client/v4";
  }

  async request(method, endpoint, data = null) {
    const url = `${this.baseUrl}${endpoint}`;
    const options = {
      method,
      headers: {
        "Authorization": `Bearer ${this.apiToken}`,
        "Content-Type": "application/json",
      },
    };

    if (data) {
      options.body = JSON.stringify(data);
    }

    const response = await fetch(url, options);
    const result = await response.json();

    if (!result.success) {
      throw new Error(`CloudFlare API Error: ${JSON.stringify(result.errors)}`);
    }

    return result.result;
  }

  // Purge Cache
  async purgeCache(files = null) {
    if (files) {
      return this.request("POST", `/zones/${this.zoneId}/purge_cache`, {
        files,
      });
    }
    return this.request("POST", `/zones/${this.zoneId}/purge_cache`, {
      purge_everything: true,
    });
  }

  // Get Cache Statistics
  async getCacheStats() {
    return this.request("GET", `/zones/${this.zoneId}/analytics/dashboard`);
  }

  // Create Cache Rule
  async createCacheRule(pattern, ttl) {
    return this.request("POST", `/zones/${this.zoneId}/cache/cache_rules`, {
      expression: `http.request.uri.path matches "${pattern}"`,
      action: "set_cache_settings",
      action_parameters: {
        cache: true,
        cache_ttl: ttl,
      },
    });
  }

  // List Page Rules
  async getPageRules() {
    return this.request("GET", `/zones/${this.zoneId}/pagerules`);
  }

  // Create Page Rule
  async createPageRule(targets, actions) {
    return this.request("POST", `/zones/${this.zoneId}/pagerules`, {
      targets,
      actions,
      priority: 1,
      status: "active",
    });
  }

  // Get Zone Settings
  async getZoneSettings() {
    return this.request("GET", `/zones/${this.zoneId}/settings`);
  }

  // Get Analytics
  async getAnalytics(since, until) {
    return this.request(
      "GET",
      `/zones/${this.zoneId}/analytics/http_requests?since=${since}&until=${until}`
    );
  }
}

export const cfClient = new CloudFlareClient(
  process.env.CLOUDFLARE_ZONE_ID,
  process.env.CLOUDFLARE_API_TOKEN
);