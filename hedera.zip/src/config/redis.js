import redis from "redis";
import { createClient } from "redis";

const redisClient = createClient({
  host: process.env.REDIS_HOST || "localhost",
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
  retry_strategy: (options) => {
    if (options.total_retry_time > 1000 * 60 * 60) {
      return new Error("Redis max retry time exceeded");
    }
    return Math.min(options.attempt * 100, 3000);
  },
});

redisClient.on("error", (err) => {
  console.error("❌ Redis Client Error", err);
});

redisClient.on("connect", () => {
  console.log("✅ Redis connected");
});

export async function cacheGet(key) {
  try {
    return await redisClient.get(key);
  } catch (error) {
    console.error("Cache get error:", error);
    return null;
  }
}

export async function cacheSet(key, value, ttl = 3600) {
  try {
    await redisClient.setEx(key, ttl, JSON.stringify(value));
  } catch (error) {
    console.error("Cache set error:", error);
  }
}

export async function cacheDel(key) {
  try {
    await redisClient.del(key);
  } catch (error) {
    console.error("Cache delete error:", error);
  }
}

export async function cacheFlush() {
  try {
    await redisClient.flushDb();
  } catch (error) {
    console.error("Cache flush error:", error);
  }
}

export default redisClient;