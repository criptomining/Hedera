/**
 * Mobile Optimization Tests
 */

import fetch from "node-fetch";

const BASE_URL = process.env.TEST_URL || "http://localhost:3000";

const mobileTests = [
  {
    name: "Responsive Meta Tag",
    test: async () => {
      const res = await fetch(`${BASE_URL}/`);
      const html = await res.text();
      return html.includes('viewport');
    },
  },
  {
    name: "Minimal Initial Load",
    test: async () => {
      const res = await fetch(`${BASE_URL}/index-pwa.html`);
      const size = res.headers.get("content-length");
      return size && parseInt(size) < 50000; // < 50KB
    },
  },
  {
    name: "Touch-friendly Buttons",
    test: async () => {
      const res = await fetch(`${BASE_URL}/index-pwa.html`);
      const html = await res.text();
      return html.includes('touch-action') || html.includes('button');
    },
  },
  {
    name: "App Icon",
    test: async () => {
      const res = await fetch(`${BASE_URL}/icons/icon-192.png`);
      return res.status === 200;
    },
  },
];

async function runTests() {
  console.log("📱 Mobile Optimization Tests");
  console.log("============================\n");

  for (const test of mobileTests) {
    try {
      const result = await test.test();
      console.log(`${result ? "✅" : "❌"} ${test.name}`);
    } catch (error) {
      console.log(`❌ ${test.name} - ${error.message}`);
    }
  }
}

runTests();