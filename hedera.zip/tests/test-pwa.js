/**
 * PWA Testing
 * Verify all PWA features
 */

import fetch from "node-fetch";
import fs from "fs";

const BASE_URL = process.env.TEST_URL || "http://localhost:3000";

const tests = [
  {
    name: "Service Worker Registration",
    test: async () => {
      const res = await fetch(`${BASE_URL}/service-worker.js`);
      return res.status === 200;
    },
  },
  {
    name: "Manifest File",
    test: async () => {
      const res = await fetch(`${BASE_URL}/manifest.json`);
      return res.status === 200 && res.headers.get("content-type").includes("json");
    },
  },
  {
    name: "Offline Page",
    test: async () => {
      const res = await fetch(`${BASE_URL}/offline.html`);
      return res.status === 200;
    },
  },
  {
    name: "Icons Available",
    test: async () => {
      const icons = [
        "/icons/icon-192.png",
        "/icons/icon-512.png",
      ];
      for (const icon of icons) {
        const res = await fetch(`${BASE_URL}${icon}`);
        if (res.status !== 200) return false;
      }
      return true;
    },
  },
  {
    name: "HTTPS/HTTP2 Headers",
    test: async () => {
      const res = await fetch(`${BASE_URL}/`);
      const headers = res.headers;
      return (
        headers.get("strict-transport-security") !== null ||
        res.url.startsWith("https")
      );
    },
  },
  {
    name: "Cache Headers",
    test: async () => {
      const res = await fetch(`${BASE_URL}/`);
      return res.headers.get("cache-control") !== null;
    },
  },
  {
    name: "Compression",
    test: async () => {
      const res = await fetch(`${BASE_URL}/`, {
        headers: { "Accept-Encoding": "gzip, deflate" },
      });
      return res.headers.get("content-encoding") !== null;
    },
  },
];

async function runTests() {
  console.log("🧪 PWA Feature Tests");
  console.log("====================\n");

  let passed = 0;
  let failed = 0;

  for (const test of tests) {
    try {
      const result = await test.test();
      if (result) {
        console.log(`✅ ${test.name}`);
        passed++;
      } else {
        console.log(`❌ ${test.name}`);
        failed++;
      }
    } catch (error) {
      console.log(`❌ ${test.name} - Error: ${error.message}`);
      failed++;
    }
  }

  console.log(`\n📊 Results: ${passed}/${tests.length} passed`);
  process.exit(failed > 0 ? 1 : 0);
}

runTests();