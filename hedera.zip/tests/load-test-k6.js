/**
 * Load Testing with k6
 * Run with: k6 run tests/load-test-k6.js
 */

import http from "k6/http";
import { check, group, sleep } from "k6";
import { Rate, Trend, Counter, Gauge } from "k6/metrics";

const BASE_URL = __ENV.TEST_URL || "http://localhost:3000";
const TEST_TOKEN = __ENV.TEST_TOKEN || "test-token";

// Custom metrics
const errorRate = new Rate("error_rate");
const requestDuration = new Trend("request_duration");
const requestCount = new Counter("request_count");
const concurrentConnections = new Gauge("concurrent_connections");

// Test configuration
export const options = {
  stages: [
    // Ramp up
    { duration: "30s", target: 50 },
    { duration: "1m", target: 100 },
    { duration: "2m", target: 200 },

    // Sustained load
    { duration: "3m", target: 200 },

    // Stress test
    { duration: "1m", target: 500 },
    { duration: "1m", target: 1000 },

    // Ramp down
    { duration: "1m", target: 100 },
    { duration: "30s", target: 0 },
  ],

  thresholds: {
    "http_req_duration": ["p(95)<500", "p(99)<1000"],
    "http_req_failed": ["rate<0.1"],
    "error_rate": ["rate<0.05"],
  },

  ext: {
    loadimpact: {
      projectID: 12345,
      name: "Hedera Load Test",
    },
  },
};

export default function () {
  // Health check
  group("Health Check", () => {
    const res = http.get(`${BASE_URL}/api/health`);
    check(res, {
      "health status is 200": (r) => r.status === 200,
      "response time < 200ms": (r) => r.timings.duration < 200,
    });
    errorRate.add(res.status !== 200);
    requestDuration.add(res.timings.duration);
    requestCount.add(1);
  });

  sleep(1);

  // List accounts
  group("List Accounts", () => {
    const res = http.get(`${BASE_URL}/api/accounts/list`, {
      headers: {
        Authorization: `Bearer ${TEST_TOKEN}`,
      },
    });
    check(res, {
      "list status is 200": (r) => r.status === 200,
      "response time < 500ms": (r) => r.timings.duration < 500,
    });
    errorRate.add(res.status !== 200);
    requestDuration.add(res.timings.duration);
  });

  sleep(1);

  // Dashboard
  group("Dashboard Load", () => {
    const res = http.get(`${BASE_URL}/dashboard.html`);
    check(res, {
      "dashboard status is 200": (r) => r.status === 200,
      "has cache header": (r) => r.headers["Cache-Control"],
    });
    errorRate.add(res.status !== 200);
    requestDuration.add(res.timings.duration);
  });

  sleep(1);

  // Geo Dashboard
  group("Geo Dashboard", () => {
    const res = http.get(`${BASE_URL}/geo-dashboard.html`);
    check(res, {
      "geo dashboard status is 200": (r) => r.status === 200,
    });
    errorRate.add(res.status !== 200);
    requestDuration.add(res.timings.duration);
  });

  sleep(1);

  // Analytics
  group("Analytics", () => {
    const res = http.get(`${BASE_URL}/api/analytics/user?days=30`, {
      headers: {
        Authorization: `Bearer ${TEST_TOKEN}`,
      },
    });
    check(res, {
      "analytics status is 200": (r) => r.status === 200,
      "response time < 1000ms": (r) => r.timings.duration < 1000,
    });
    errorRate.add(res.status !== 200);
    requestDuration.add(res.timings.duration);
  });

  sleep(1);

  // Concurrent requests
  group("Concurrent Requests", () => {
    const requests = {
      health: {
        method: "GET",
        url: `${BASE_URL}/api/health`,
      },
      geo: {
        method: "GET",
        url: `${BASE_URL}/api/geo/location`,
      },
      metrics: {
        method: "GET",
        url: `${BASE_URL}/api/metrics`,
      },
    };

    const responses = http.batch(requests);

    check(responses.health, {
      "health status is 200": (r) => r.status === 200,
    });
    check(responses.geo, {
      "geo status is 200": (r) => r.status === 200,
    });
    check(responses.metrics, {
      "metrics status is 200": (r) => r.status === 200,
    });

    responses.forEach((r) => {
      errorRate.add(r.status !== 200);
      requestDuration.add(r.timings.duration);
    });
  });

  concurrentConnections.set(__VU);
  sleep(2);
}

/**
 * Summary function - called after test finishes
 */
export function handleSummary(data) {
  return {
    "stdout": textSummary(data, { indent: " ", enableColors: true }),
    "summary.json": JSON.stringify(data),
  };
}