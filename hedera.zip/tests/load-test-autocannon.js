/**
 * Load Testing with Autocannon
 * High-performance HTTP benchmarking
 */

import autocannon from "autocannon";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const BASE_URL = process.env.TEST_URL || "http://localhost:3000";

// Test scenarios
const testScenarios = [
  {
    name: "Health Check",
    path: "/api/health",
    duration: 10,
    connections: 10,
  },
  {
    name: "List Accounts",
    path: "/api/accounts/list",
    duration: 15,
    connections: 20,
    headers: {
      Authorization: `Bearer ${process.env.TEST_TOKEN}`,
    },
  },
  {
    name: "Dashboard Load",
    path: "/dashboard.html",
    duration: 20,
    connections: 50,
  },
  {
    name: "Geo Dashboard Load",
    path: "/geo-dashboard.html",
    duration: 20,
    connections: 50,
  },
  {
    name: "Analytics Fetch",
    path: "/api/analytics/user?days=30",
    duration: 15,
    connections: 30,
    headers: {
      Authorization: `Bearer ${process.env.TEST_TOKEN}`,
    },
  },
  {
    name: "Concurrent Requests",
    path: "/api/health",
    duration: 30,
    connections: 100,
    pipelining: 10,
  },
];

async function runLoadTest(scenario) {
  console.log(`\n🚀 Running test: ${scenario.name}`);
  console.log(`📍 Path: ${scenario.path}`);
  console.log(`⏱️  Duration: ${scenario.duration}s`);
  console.log(`🔗 Connections: ${scenario.connections}`);

  const result = await autocannon({
    url: `${BASE_URL}${scenario.path}`,
    connections: scenario.connections,
    pipelining: scenario.pipelining || 1,
    duration: scenario.duration,
    requests: scenario.requests,
    headers: scenario.headers,
    maxSockets: scenario.connections * 2,
    timeout: 60,
  });

  return {
    scenario: scenario.name,
    ...result,
  };
}

async function runAllTests() {
  console.log("==========================================");
  console.log("🔥 LOAD TEST SUITE - AUTOCANNON");
  console.log("==========================================");
  console.log(`🎯 Target: ${BASE_URL}`);
  console.log(`📅 Date: ${new Date().toISOString()}`);

  const results = [];
  let totalErrors = 0;

  for (const scenario of testScenarios) {
    try {
      const result = await runLoadTest(scenario);
      results.push(result);

      // Display results
      console.log(`\n✅ ${scenario.name} Results:`);
      console.log(`   Requests: ${result.requests.total}`);
      console.log(`   Throughput: ${(result.throughput.average / 1024).toFixed(2)} KB/s`);
      console.log(`   Latency: ${result.latency.mean.toFixed(2)}ms (avg)`);
      console.log(`   P99: ${result.latency.p99}ms`);
      console.log(`   Errors: ${result.errors}`);
      console.log(`   Timeouts: ${result.timeouts}`);

      totalErrors += result.errors;
    } catch (error) {
      console.error(`❌ Test failed: ${scenario.name}`, error);
    }
  }

  // Summary
  console.log("\n==========================================");
  console.log("📊 SUMMARY");
  console.log("==========================================");
  console.log(`Total Scenarios: ${results.length}`);
  console.log(`Total Errors: ${totalErrors}`);

  const avgLatency = results.reduce((sum, r) => sum + r.latency.mean, 0) / results.length;
  console.log(`Average Latency: ${avgLatency.toFixed(2)}ms`);

  const totalThroughput = results.reduce((sum, r) => sum + r.throughput.average, 0);
  console.log(`Total Throughput: ${(totalThroughput / 1024 / 1024).toFixed(2)} MB/s`);

  // Save results
  const reportPath = path.join(__dirname, `load-test-${Date.now()}.json`);
  fs.writeFileSync(reportPath, JSON.stringify(results, null, 2));
  console.log(`\n📄 Report saved: ${reportPath}`);

  // Return exit code
  process.exit(totalErrors > 0 ? 1 : 0);
}

// Run tests
runAllTests().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});