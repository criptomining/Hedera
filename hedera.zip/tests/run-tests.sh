#!/bin/bash

set -e

echo "🧪 Starting Load Tests"
echo "====================="

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Configuration
TEST_URL=${1:-"http://localhost:3000"}
TEST_TOKEN=${2:-"test-token"}

echo -e "${BLUE}Target URL: ${TEST_URL}${NC}"
echo -e "${BLUE}Test Token: ${TEST_TOKEN}${NC}"
echo ""

# Wait for server
echo -e "${YELLOW}⏳ Waiting for server...${NC}"
for i in {1..30}; do
  if curl -s -f "$TEST_URL/api/health" > /dev/null; then
    echo -e "${GREEN}✅ Server is ready${NC}"
    break
  fi
  if [ $i -eq 30 ]; then
    echo -e "${RED}❌ Server is not responding${NC}"
    exit 1
  fi
  sleep 1
done

# Run Autocannon tests
echo ""
echo -e "${BLUE}🔥 Running Autocannon Tests${NC}"
echo -e "${YELLOW}================================${NC}"
TEST_URL="$TEST_URL" TEST_TOKEN="$TEST_TOKEN" node tests/load-test-autocannon.js

# Run k6 tests (if k6 is installed)
if command -v k6 &> /dev/null; then
  echo ""
  echo -e "${BLUE}📊 Running k6 Load Test${NC}"
  echo -e "${YELLOW}================================${NC}"
  TEST_URL="$TEST_URL" TEST_TOKEN="$TEST_TOKEN" k6 run tests/load-test-k6.js --vus 10 --duration 30s
else
  echo -e "${YELLOW}⚠️  k6 not installed. Skipping k6 tests.${NC}"
  echo "Install with: brew install k6 (macOS) or apt-get install k6 (Linux)"
fi

echo ""
echo -e "${GREEN}✅ All tests completed${NC}"