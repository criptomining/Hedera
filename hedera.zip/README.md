# ⚡ Hedera Web3 Console Pro v2.0

Secure Hedera blockchain account management with analytics dashboard.

## 🚀 Quick Start

### Local Development

```bash
# Install dependencies
npm install

# Create environment file
cp .env.example .env

# Edit .env with your credentials
nano .env

# Start development server
npm run dev