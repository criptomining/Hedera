#!/bin/bash

set -e

echo "🌍 Starting Multi-Region Deployment with CloudFlare..."

# Configuration
HEROKU_APP_US="hedera-us"
HEROKU_APP_EU="hedera-eu"
HEROKU_APP_ASIA="hedera-asia"
CLOUDFLARE_ZONE=${1:-"YOUR_ZONE_ID"}

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}================================${NC}"
echo -e "${BLUE}   MULTI-REGION DEPLOYMENT${NC}"
echo -e "${BLUE}================================${NC}"

# Deploy to US Region
echo -e "\n${YELLOW}📍 Deploying to US (us-east-1)...${NC}"
git push heroku-us main -f || true
echo -e "${GREEN}✅ US Region deployed${NC}"

# Deploy to EU Region
echo -e "\n${YELLOW}📍 Deploying to EU (eu-west-1)...${NC}"
git push heroku-eu main -f || true
echo -e "${GREEN}✅ EU Region deployed${NC}"

# Deploy to Asia Region
echo -e "\n${YELLOW}📍 Deploying to ASIA (ap-southeast-1)...${NC}"
git push heroku-asia main -f || true
echo -e "${GREEN}✅ ASIA Region deployed${NC}"

# Deploy CloudFlare Worker
echo -e "\n${YELLOW}🔧 Deploying CloudFlare Worker...${NC}"
npx wrangler publish --env production
echo -e "${GREEN}✅ CloudFlare Worker deployed${NC}"

# Configure CloudFlare
echo -e "\n${YELLOW}⚙️ Configuring CloudFlare...${NC}"

# Create cache rules
curl -X POST "https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE}/cache/cache_rules" \
  -H "Authorization: Bearer ${CLOUDFLARE_API_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "expression": "http.request.uri.path matches \"/api/*\"",
    "action": "set_cache_settings",
    "action_parameters": {
      "cache": true,
      "cache_ttl": 300
    }
  }'

echo -e "${GREEN}✅ CloudFlare cache rules configured${NC}"

# Get origins status
echo -e "\n${YELLOW}🔍 Checking origins...${NC}"
curl -s https://us-origin.herokuapp.com/api/health | jq '.' || echo "US: Checking..."
curl -s https://eu-origin.herokuapp.com/api/health | jq '.' || echo "EU: Checking..."
curl -s https://asia-origin.herokuapp.com/api/health | jq '.' || echo "ASIA: Checking..."

echo -e "\n${GREEN}================================${NC}"
echo -e "${GREEN}✅ Multi-Region Deployment Complete!${NC}"
echo -e "${GREEN}================================${NC}"
echo -e "${BLUE}Monitoring URLs:${NC}"
echo "  🌐 Global:  https://hedera.example.com"
echo "  🇺🇸 US:     https://us.hedera.example.com"
echo "  🇪🇺 EU:     https://eu.hedera.example.com"
echo "  🇦🇸 ASIA:   https://asia.hedera.example.com"