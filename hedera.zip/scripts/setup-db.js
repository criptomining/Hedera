import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.DATABASE_URL?.replace("sqlite:///", "") || path.join(__dirname, "../database/accounts.db");

console.log(`📦 Initializing database at: ${dbPath}`);

const db = new Database(dbPath);

// Enable foreign keys
db.pragma("foreign_keys = ON");

// Create tables
db.exec(`
  -- Users table
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    api_key TEXT UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME
  );

  -- Stored accounts
  CREATE TABLE IF NOT EXISTS stored_accounts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    account_id TEXT NOT NULL UNIQUE,
    encrypted_private_key TEXT NOT NULL,
    public_key TEXT,
    balance REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  -- Transactions log
  CREATE TABLE IF NOT EXISTS transaction_logs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    from_account TEXT,
    to_account TEXT,
    amount REAL,
    transaction_id TEXT,
    status TEXT DEFAULT 'pending',
    tx_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
  );

  -- Tokens created
  CREATE TABLE IF NOT EXISTS tokens (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    token_id TEXT NOT NULL UNIQUE,
    token_name TEXT,
    token_symbol TEXT,
    decimals INTEGER DEFAULT 2,
    initial_supply INTEGER,
    max_supply INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
  );

  -- Analytics events
  CREATE TABLE IF NOT EXISTS analytics_events (
    id TEXT PRIMARY KEY,
    user_id TEXT,
    event_type TEXT NOT NULL,
    event_data TEXT,
    ip_address TEXT,
    user_agent TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_type (event_type),
    INDEX idx_timestamp (timestamp),
    INDEX idx_user_id (user_id)
  );

  -- Daily analytics summary
  CREATE TABLE IF NOT EXISTS analytics_summary (
    id TEXT PRIMARY KEY,
    date DATE NOT NULL UNIQUE,
    total_users INTEGER DEFAULT 0,
    total_accounts_created INTEGER DEFAULT 0,
    total_transactions INTEGER DEFAULT 0,
    total_volume REAL DEFAULT 0,
    avg_transaction_size REAL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (date)
  );

  -- Create indexes for performance
  CREATE INDEX IF NOT EXISTS idx_stored_accounts_user_id ON stored_accounts(user_id);
  CREATE INDEX IF NOT EXISTS idx_transaction_logs_user_id ON transaction_logs(user_id);
  CREATE INDEX IF NOT EXISTS idx_transaction_logs_status ON transaction_logs(status);
  CREATE INDEX IF NOT EXISTS idx_analytics_events_timestamp ON analytics_events(timestamp);
`);

console.log("✅ Database initialized successfully");

db.close();