#!/bin/bash

echo "🚀 Starting optimized deployment..."

# Variables
HEROKU_APP=${1:-"your-app-name"}

echo "📦 Building optimized Docker image..."
docker build -f Dockerfile.optimized -t $HEROKU_APP:latest .

echo "📤 Pushing to Heroku..."
docker tag $HEROKU_APP:latest registry.heroku.com/$HEROKU_APP/web:latest
docker push registry.heroku.com/$HEROKU_APP/web:latest

echo "⚡ Releasing on Heroku..."
heroku container:release web --app=$HEROKU_APP

echo "📊 Starting performance monitoring..."
heroku logs --tail --app=$HEROKU_APP

echo "✅ Deployment complete!"
echo "📈 View performance metrics: https://$HEROKU_APP.herokuapp.com/performance.html"