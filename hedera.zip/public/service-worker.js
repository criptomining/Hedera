/**
 * Service Worker - PWA Offline & Caching Strategy
 */

const CACHE_VERSION = "v1.0.0";
const CACHE_NAMES = {
  static: `hedera-static-${CACHE_VERSION}`,
  dynamic: `hedera-dynamic-${CACHE_VERSION}`,
  images: `hedera-images-${CACHE_VERSION}`,
  api: `hedera-api-${CACHE_VERSION}`,
};

// Assets to cache on install
const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/dashboard.html",
  "/geo-dashboard.html",
  "/performance.html",
  "/offline.html",
  "/css/style.css",
  "/js/app.js",
  "/js/chart.min.js",
  "/manifest.json",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
];

// Install event - cache static assets
self.addEventListener("install", (event) => {
  console.log("🔧 Service Worker installing...");

  event.waitUntil(
    caches
      .open(CACHE_NAMES.static)
      .then((cache) => {
        console.log("📦 Caching static assets");
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean old caches
self.addEventListener("activate", (event) => {
  console.log("✅ Service Worker activating...");

  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (!Object.values(CACHE_NAMES).includes(cacheName)) {
            console.log(`🗑️ Deleting old cache: ${cacheName}`);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );

  return self.clients.claim();
});

// Fetch event - intelligent caching strategy
self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests
  if (request.method !== "GET") {
    return;
  }

  // Skip cross-origin requests
  if (url.origin !== location.origin) {
    return;
  }

  // API requests - Network first, fallback to cache
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(networkFirstStrategy(request, CACHE_NAMES.api));
    return;
  }

  // Images - Cache first
  if (
    url.pathname.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i) ||
    url.pathname.startsWith("/icons/")
  ) {
    event.respondWith(cacheFirstStrategy(request, CACHE_NAMES.images));
    return;
  }

  // Static assets - Cache first
  if (
    url.pathname.match(/\.(css|js|woff|woff2|ttf|eot)$/i) ||
    url.pathname.includes("manifest.json")
  ) {
    event.respondWith(cacheFirstStrategy(request, CACHE_NAMES.static));
    return;
  }

  // HTML files - Network first, fallback to cache
  if (url.pathname.endsWith(".html") || url.pathname === "/") {
    event.respondWith(networkFirstStrategy(request, CACHE_NAMES.static));
    return;
  }

  // Default - Network first
  event.respondWith(networkFirstStrategy(request, CACHE_NAMES.dynamic));
});

/**
 * Network First Strategy
 * Try network first, fallback to cache
 */
async function networkFirstStrategy(request, cacheName) {
  try {
    const response = await fetch(request);

    // Cache successful responses
    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }

    return response;
  } catch (error) {
    // Network failed, try cache
    const cached = await caches.match(request);
    if (cached) {
      return cached;
    }

    // No cache, return offline page
    if (request.destination === "document") {
      return caches.match("/offline.html");
    }

    return new Response("Network error", { status: 503 });
  }
}

/**
 * Cache First Strategy
 * Try cache first, fallback to network
 */
async function cacheFirstStrategy(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) {
    return cached;
  }

  try {
    const response = await fetch(request);

    if (response.ok) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }

    return response;
  } catch (error) {
    return new Response("Network error", { status: 503 });
  }
}

/**
 * Background Sync for offline actions
 */
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-transactions") {
    event.waitUntil(syncPendingTransactions());
  }
});

async function syncPendingTransactions() {
  const db = await openIndexedDB();
  const pendingTxs = await db.getAll("pending_transactions");

  for (const tx of pendingTxs) {
    try {
      const response = await fetch("/api/transactions/transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(tx),
      });

      if (response.ok) {
        await db.delete("pending_transactions", tx.id);
      }
    } catch (error) {
      console.error("Sync failed:", error);
    }
  }
}

/**
 * Push notifications
 */
self.addEventListener("push", (event) => {
  const data = event.data.json();

  const options = {
    body: data.body,
    icon: "/icons/icon-192.png",
    badge: "/icons/badge-72.png",
    tag: data.tag || "notification",
    requireInteraction: false,
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll().then((clientList) => {
      if (clientList.length > 0) {
        return clientList[0].focus();
      }
      return clients.openWindow("/");
    })
  );
});