/**
 * IndexedDB Management
 * Local storage for offline capabilities
 */

class IndexedDBManager {
  constructor(dbName = "hedera-app", version = 1) {
    this.dbName = dbName;
    this.version = version;
    this.db = null;
  }

  async init() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve(this.db);
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // Create object stores
        const stores = [
          {
            name: "accounts",
            keyPath: "id",
            indexes: [
              { name: "accountId", unique: true },
              { name: "userId", unique: false },
            ],
          },
          {
            name: "transactions",
            keyPath: "id",
            indexes: [
              { name: "txId", unique: true },
              { name: "timestamp", unique: false },
            ],
          },
          {
            name: "pending_transactions",
            keyPath: "id",
            indexes: [
              { name: "status", unique: false },
              { name: "timestamp", unique: false },
            ],
          },
          {
            name: "cache",
            keyPath: "key",
            indexes: [
              { name: "expiry", unique: false },
            ],
          },
          {
            name: "analytics",
            keyPath: "id",
            indexes: [
              { name: "timestamp", unique: false },
              { name: "type", unique: false },
            ],
          },
        ];

        stores.forEach((store) => {
          if (!db.objectStoreNames.contains(store.name)) {
            const os = db.createObjectStore(store.name, { keyPath: store.keyPath });
            store.indexes.forEach((index) => {
              os.createIndex(index.name, index.name, { unique: index.unique });
            });
          }
        });
      };
    });
  }

  async add(storeName, data) {
    const tx = this.db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.add(data);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async put(storeName, data) {
    const tx = this.db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.put(data);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async get(storeName, key) {
    const tx = this.db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.get(key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async getAll(storeName) {
    const tx = this.db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async delete(storeName, key) {
    const tx = this.db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.delete(key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async clear(storeName) {
    const tx = this.db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    return new Promise((resolve, reject) => {
      const request = store.clear();
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async queryIndex(storeName, indexName, value) {
    const tx = this.db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const index = store.index(indexName);
    return new Promise((resolve, reject) => {
      const request = index.getAll(value);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async setCache(key, value, ttl = 3600) {
    const expiryTime = Date.now() + ttl * 1000;
    await this.put("cache", {
      key,
      value,
      expiry: expiryTime,
      timestamp: Date.now(),
    });
  }

  async getCache(key) {
    const cached = await this.get("cache", key);
    if (!cached) return null;

    if (cached.expiry < Date.now()) {
      await this.delete("cache", key);
      return null;
    }

    return cached.value;
  }

  async addPendingTransaction(txData) {
    return this.add("pending_transactions", {
      id: `tx-${Date.now()}`,
      ...txData,
      status: "pending",
      timestamp: Date.now(),
    });
  }

  async getPendingTransactions() {
    return this.queryIndex("pending_transactions", "status", "pending");
  }
}

// Global instance
const indexedDB_manager = new IndexedDBManager();
indexedDB_manager.init().then(() => {
  console.log("✅ IndexedDB initialized");
});

export default IndexedDBManager;